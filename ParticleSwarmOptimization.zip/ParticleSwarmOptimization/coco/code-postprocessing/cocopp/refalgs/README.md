Reference Algorithms for BBOB Test Suites
=========================================

The COCO platform provides several reference algorithms, constructed from 
sets of algorithm data sets, as submitted to the BBOB workshop series.

The most common ones are provided here while reference algorithms for
other years are available at http://coco.gforge.inria.fr/refalgs/ .